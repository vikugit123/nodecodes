const mongoose = require('mongoose');

const productModel = mongoose.Schema({
  name: { 
  	type: String, 
  	required: '{PATH} is required!'
  },
  sku: {
  	type: String
  },
  price: {
  	type: double
  },
  mrp_price: {
    type: double
},
image: {
    type: string
},
  brands: [
    { type: mongoose.Schema.Types.ObjectId, ref: 'Brand' }
  ]
}, {
  timestamps: true
});

module.exports = mongoose.model('Product', productModel);
