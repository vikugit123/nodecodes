const mongoose = require('mongoose');

const brandModel = mongoose.Schema({
  name: { 
  	type: String, 
  	required: 'Brand name is required!'
  },
  image: {
  	type: String
  },
  isDeleted: {
  	type: Integer
  },
  products: [
    { type: mongoose.Schema.Types.ObjectId, ref: 'Product' }
  ]
}, {
  timestamps: true
});

module.exports = mongoose.model('Brand', brandModel);
