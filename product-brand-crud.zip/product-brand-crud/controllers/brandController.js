const { Brand } = require('./Brand');
const { Product } = require('./Product');

const BrandsController = {
  async index(req, res){
  	const brands = await Brand.find().populate('products');
  	res.send(brands);
  },
  async show(req, res){
  	const brand = await Brand.findById(req.params.id).populate('products');
  	res.send(brand);
  }
};

module.exports = BrandsController;