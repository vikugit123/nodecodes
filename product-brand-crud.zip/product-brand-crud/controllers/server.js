const Express = require("express");
const BodyParser = require("body-parser");
const MongoClient = require("mongodb").MongoClient;
const ObjectId = require("mongodb").ObjectID;

var app = Express();
app.use(BodyParser.json());
app.use(BodyParser.urlencoded({ extended: true }));
router = express.Router(),
brandController=require('./controllers/BrandsController');
productController=require('./controllers/ProductsController');
router.get('/brands', brandController.index);
router.get('/brand/:id', brandController.show);
router.get('/products', productController.index);
router.get('/brand/:id', productController.show);

	app.use('/api', router);
app.listen(5000, () => {});