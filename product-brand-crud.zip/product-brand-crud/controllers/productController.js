const { Brand } = require('./Brand');
const { Product } = require('./Product');

const match = {};
const ProductsController = {
  async index(req, res){
  	const products = await Product.find().populate(
          { path:'brands',
      match,
      options:{
          limit: parseInt(req.query.limit),
          skip: parseInt(req.query.skip),
          sort
      }
      });
  	res.send(products);
  },
  async show(req, res){
  	const product = await Product.findById(req.params.id).populate('brands');
  	res.send(product);
  }
};

module.exports = ProductsController;